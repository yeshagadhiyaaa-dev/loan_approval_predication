import pandas as pd
import numpy as np 
import matplotlib.pyplot as plt  
import seaborn as sns 
import sweetviz as sv
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score,precision_score,recall_score,f1_score
from sklearn.metrics import confusion_matrix
from sklearn.model_selection import cross_val_score
from sklearn.linear_model import LogisticRegression
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler

#...........................2.import data set......................................................
df=pd.read_csv("loanapproval.csv")
print(df)
#df.info()

#...........................3.Understanding data.....................................................

#QTT:

print("\nQTT data:,int64 and float64")
quantitative = df.select_dtypes(include=["int64","float64"])
print("QTT data :",quantitative)
print("QTT colums label:\n",quantitative.columns)

#QLT:

print("\nQLT data:,object and category")
qualitative = df.select_dtypes(include=["object","category"])
print("QLT data :",qualitative)
print("QLT colums label:\n",qualitative.columns)

#NULL VALUES:

print(df.isnull().sum())
df.isnull().any

#DUPLICATE:

duplicates=df[df.duplicated(keep=False)]
print("duplicates:")
print(duplicates)

#.......................................4.Exploratory data analysis...............................

#HISTROGRAM:

plt.figure()
hrs=df.annual_income
sns.histplot(hrs,kde=True)
plt.title("annual-income v/s loan-approved")
plt.xlabel("annual_income")
plt.ylabel("loan_approved")
plt.show()

#BOX_PLOT:

plt.figure(figsize=(10,6))
plt.boxplot([
    df["age"],
    df["annual_income"],
    df["loan_amount"],
    df["credit_score"]
])
plt.xticks(
    [1,2,3,4],
    ["age","annual_income","loan_amount","credit_score"]
)
plt.title("loan approval dataset - Box Plot")
plt.ylabel("Values")
plt.show()

#PIE CHARTS:

approval=df["loan_approved"].value_counts()
plt.pie(
    approval.values,
    labels=["not approved","approved"],
    autopct="%1.1f%%",
    startangle=90
)
plt.title("loan approval status")
plt.show()


#BAR CHART:

approval=df["loan_approved"].value_counts()
plt.bar(
    ["not approved","approved"],
    approval.values,
    color=["red","green"]
)
plt.xlabel("loan status")
plt.ylabel("number of applicants")
plt.title("loan approval bar charts")
plt.show()


#CORRELATION:

print("correlation:")
print(df.corr(numeric_only=True))

#.....................................5.Handle Missing values and outliers..........................

#OUTLLIERS:

numeric_columns = df.select_dtypes(include="number").columns
df[numeric_columns].boxplot(figsize=(12, 6))

plt.title("outliers detection using boxplot")
plt.xticks(rotation=45)
plt.show()

#..................................6.Automated EDA..................................................
#PANDAS PROFILIND:

'''df=pd.read_csv("loanapproval.csv")
profile=ProfileReport(df)
profile.to_file("report.html")'''


#SWEETVIZ:

df=pd.read_csv("loanapproval.csv")
report=sv.analyze(df)
report.show_html()

#AUOTOVIZ:

'''AV=AutoViz_Class()
df=AV.AuotoViz("stud_performance.csv")'''

#......................................7.Feature Selection............................................
X = df[['age','gender','marital_status','annual_income','loan_amount',
        'credit_score','num_dependents','existing_loans_count','employment_status']]
y = df['loan_approved']

# text કૉલમને number માં બદલો (split પહેલા)
X =pd.get_dummies(X, drop_first=True)

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y)

scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)


#TRAIN-TEST-SPLIT:
plt.scatter(df['annual_income'],y)
plt.xlabel("annual_income")
plt.ylabel("loan_approved")
plt.title("annual_income vs loan_approved")
plt.show()

#...........................................8.Build ML Model......................................
#Model
model=LogisticRegression()
model.fit(X_train,y_train)

#prediction
y_pred=model.predict(X_test)

print("prediction:",y_pred)
print("Actual:",y_test)

#.............................................9.MODEL EVALUTION...................................
#Accuracy:
cm=confusion_matrix(y_test,y_pred)
print("confusion matrix")
print(cm)

print("accuracy:",accuracy_score(y_test,y_pred))
print("precision:",precision_score(y_test,y_pred))
print("recall:",recall_score(y_test,y_pred))
print("f1 score:",f1_score(y_test,y_pred))

#............................................10.Improve Model.......................................
#CROSS VALIDATION:

model = LogisticRegression(max_iter=1000)
scores = cross_val_score(model, X, y, cv=5, scoring='accuracy')

# Display accuracy of each fold
print("\nAccuracy of each fold:")
print(scores)

# Calculate average accuracy
print("\nAverage Accuracy:", scores.mean())

#L1 REGRESSION:

l1_model = LogisticRegression (penalty='l1', solver='saga', max_iter=1000)
l1_model.fit(X_train, y_train)
y_pred_l1 = l1_model.predict(X_test)
l1_accuracy = accuracy_score(y_test, y_pred_l1)
print("Accuracy:", l1_accuracy)
print("Coefficients:")
print(l1_model.coef_)

#L2 REGRESSION:

l2_model = LogisticRegression (penalty='l2', solver='saga', max_iter=1000)
l2_model.fit(X_train, y_train)
y_pred_l2 = l2_model.predict(X_test)
l2_accuracy = accuracy_score(y_test, y_pred_l2)
print("Accuracy:", l2_accuracy)
print("Coefficients:")
print(l2_model.coef_)
  



